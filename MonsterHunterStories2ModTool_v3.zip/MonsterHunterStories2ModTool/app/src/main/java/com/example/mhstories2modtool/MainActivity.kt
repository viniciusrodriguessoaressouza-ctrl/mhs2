package com.example.mhstories2modtool

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { NspAnalyzerScreen() } }
    }
}

private data class NspReport(
    val fileName: String,
    val sizeBytes: Long,
    val extensionLooksCorrect: Boolean,
    val zipReadable: Boolean,
    val entryCount: Int,
    val selectedNames: List<String>,
    val sha256: String?,
    val notes: List<String>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NspAnalyzerScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var report by remember { mutableStateOf<NspReport?>(null) }
    var status by remember { mutableStateOf("Selecione um arquivo .NSP para analisar.") }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            busy = true
            report = null
            status = "Analisando arquivo localmente…"
            scope.launch {
                val result = withContext(Dispatchers.IO) { inspectNsp(context, uri) }
                report = result
                status = if (result.extensionLooksCorrect) {
                    "Análise inicial concluída. A estrutura identificada não garante que o pacote possa ser convertido em APK."
                } else {
                    "O arquivo selecionado não tem extensão .NSP; confira se escolheu o arquivo correto."
                }
                busy = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.Icon(Icons.Default.Android, contentDescription = null)
                    Spacer(Modifier.width(10.dp))
                    Text("MH Stories 2 Mod Tool", fontWeight = FontWeight.Bold)
                }
            })
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding)
                .verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Analisador de arquivos NSP", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Selecione um arquivo do Nintendo Switch. Esta versão faz verificações básicas e não envia o arquivo para a internet.")
                    Button(
                        onClick = { picker.launch(arrayOf("*/*")) },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        androidx.compose.material3.Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Selecionar arquivo NSP")
                    }
                    if (busy) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.width(22.dp).height(22.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text("Verificando…")
                        }
                    }
                }
            }

            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Icon(Icons.Default.Security, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Estado", fontWeight = FontWeight.Bold)
                    }
                    Text(status)
                }
            }

            report?.let { r ->
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Relatório de análise", fontWeight = FontWeight.Bold)
                        Text("Arquivo: ${r.fileName}")
                        Text("Tamanho: ${formatBytes(r.sizeBytes)}")
                        Text("Extensão .NSP: ${yesNo(r.extensionLooksCorrect)}")
                        Text("Estrutura NSP (PFS0) válida: ${yesNo(r.zipReadable)}")
                        Text("Arquivos dentro do NSP: ${r.entryCount}")
                        Text("SHA-256: ${r.sha256 ?: "Não calculado"}")
                        if (r.selectedNames.isNotEmpty()) {
                            Divider()
                            Text("Primeiros arquivos do pacote:", fontWeight = FontWeight.SemiBold)
                            r.selectedNames.forEach { Text("• $it") }
                        }
                        Divider()
                        r.notes.forEach { Text("• $it") }
                    }
                }
            }

            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Icon(Icons.Default.Info, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Limitações desta versão", fontWeight = FontWeight.Bold)
                    }
                    Text("Arquivos NSP de Nintendo Switch não são APKs. Eles usam o formato PFS0, que este app lê apenas para listar o conteúdo.")
                    Text("O aplicativo não descriptografa, não modifica o jogo e não converte NSP em APK. Um port Android exigiria adaptação ou reconstrução substancial do software.")
                }
            }
        }
    }
}

private fun readFully(input: java.io.InputStream, n: Int): ByteArray? {
    val buf = ByteArray(n)
    var off = 0
    while (off < n) {
        val r = input.read(buf, off, n - off)
        if (r < 0) return null
        off += r
    }
    return buf
}

private fun inspectNsp(context: Context, uri: Uri): NspReport {
    val name = queryDisplayName(context, uri) ?: "arquivo.nsp"
    val extensionOk = name.endsWith(".nsp", ignoreCase = true)
    var size = 0L
    var digest: String? = null
    var pfs0Valid = false
    var count = 0
    val names = mutableListOf<String>()
    val notes = mutableListOf<String>()

    try {
        // 1) Cabeçalho PFS0 (formato real de um NSP)
        context.contentResolver.openInputStream(uri)?.use { input ->
            val head = readFully(input, 16)
            if (head != null && String(head, 0, 4, Charsets.US_ASCII) == "PFS0") {
                val bb = ByteBuffer.wrap(head).order(ByteOrder.LITTLE_ENDIAN)
                val fileCount = bb.getInt(4)
                val strSize = bb.getInt(8)
                if (fileCount in 1..100000 && strSize in 0..(16 * 1024 * 1024)) {
                    val entries = readFully(input, fileCount * 24)
                    val strTable = readFully(input, strSize)
                    if (entries != null && strTable != null) {
                        val eb = ByteBuffer.wrap(entries).order(ByteOrder.LITTLE_ENDIAN)
                        for (i in 0 until fileCount) {
                            if (names.size >= 20) break
                            val off = eb.getInt(i * 24 + 16)
                            if (off < 0 || off >= strTable.size) continue
                            var end = off
                            while (end < strTable.size && strTable[end] != 0.toByte()) end++
                            names += String(strTable, off, end - off, Charsets.UTF_8)
                        }
                        count = fileCount
                        pfs0Valid = true
                    }
                }
            }
        }

        // 2) SHA-256 em streaming (sem copiar o arquivo, sem limite de tamanho)
        val md = MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Não foi possível abrir o arquivo." }
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                size += n
                md.update(buffer, 0, n)
            }
        }
        digest = md.digest().joinToString("") { "%02x".format(it) }

        if (!extensionOk) notes += "A extensão do arquivo não é .NSP."
        if (pfs0Valid) {
            notes += "Estrutura PFS0 (padrão de NSP) reconhecida."
        } else {
            notes += "Cabeçalho PFS0 não encontrado. O arquivo pode estar corrompido ou ser de outro formato (ex.: XCI)."
        }
        notes += "O hash SHA-256 identifica este arquivo, mas não verifica se o jogo é autêntico."
        notes += "Nenhuma conversão ou modificação foi realizada."
        return NspReport(name, size, extensionOk, pfs0Valid, count, names, digest, notes)
    } catch (e: Exception) {
        return NspReport(name, size, extensionOk, false, 0, emptyList(), digest,
            listOf(e.message ?: "Erro desconhecido durante a análise.", "Nenhuma conversão ou modificação foi realizada."))
    }
}

private fun queryDisplayName(context: Context, uri: Uri): String? {
    return try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
    } catch (_: Exception) { null }
}

private fun yesNo(value: Boolean) = if (value) "Sim" else "Não"

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "%.1f KB".format(kb)
    val mb = kb / 1024.0
    if (mb < 1024) return "%.1f MB".format(mb)
    return "%.2f GB".format(mb / 1024.0)
}
