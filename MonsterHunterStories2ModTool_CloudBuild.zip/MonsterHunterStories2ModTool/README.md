# Monster Hunter Stories 2 Mod Tool — protótipo 0.2.0

Aplicativo Android nativo para seleção e análise básica de arquivos `.NSP`.

## Funcionalidades
- Seleciona arquivos por meio do seletor de documentos Android.
- Copia o arquivo para o cache privado, com limite de 1 GiB.
- Calcula o hash SHA-256.
- Tenta ler o contêiner como ZIP e, se funcionar, lista até 20 entradas.
- Exibe um relatório básico.
- Apaga a cópia temporária após a análise.

## Limitações
- Não converte NSP em APK.
- Não descriptografa, modifica nem instala jogos.
- A leitura ZIP não confirma que o arquivo seja um NSP válido.
- O projeto não foi compilado nem testado em Android Studio nesta entrega.

## Compilar
1. Abra a pasta no Android Studio recente.
2. Use JDK 17 e Android SDK Platform 35.
3. Aguarde a sincronização do Gradle.
4. Selecione Build > Build APK(s), ou execute em um dispositivo conectado.

## Estrutura
- Kotlin + Jetpack Compose
- Android Storage Access Framework
- Java `ZipFile` e `MessageDigest`
