# Como gerar o APK pelo celular usando GitHub Actions

Este projeto ainda é o código-fonte; o APK é gerado por um computador virtual na nuvem.

1. Extraia o ZIP no celular.
2. No GitHub, crie um repositório novo (pode ser privado).
3. Envie os arquivos e pastas que estão dentro de `MonsterHunterStories2ModTool` para a raiz do repositório, incluindo a pasta oculta `.github/workflows`.
4. Abra a aba **Actions** e selecione **Build Android APK**. Se necessário, toque em **Run workflow**.
5. Aguarde a execução terminar com sucesso.
6. Abra a execução concluída e baixe o artefato `MonsterHunterStories2ModTool-debug-apk`.
7. Extraia o artefato baixado para obter `app-debug.apk` e instale-o no Android, permitindo a instalação dessa origem quando o sistema solicitar.

Observações:
- A compilação exige acesso ao GitHub e conexão com a internet.
- O APK gerado é de depuração, não assinado para publicação na Play Store.
- O app analisa informações básicas do arquivo escolhido; ele não converte o jogo NSP em APK.
