package com.example.mhstories2modtool

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { NspAnalyzerScreen() } }
    }
}

private data class NspReport(
    val fileName: String,
    val sizeBytes: Long,
    val extensionLooksCorrect: Boolean,
    val zipReadable: Boolean,
    val entryCount: Int,
    val selectedNames: List<String>,
    val sha256: String?,
    val notes: List<String>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NspAnalyzerScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var report by remember { mutableStateOf<NspReport?>(null) }
    var status by remember { mutableStateOf("Selecione um arquivo .NSP para analisar.") }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            busy = true
            report = null
            status = "Analisando arquivo localmente…"
            scope.launch {
                val result = withContext(Dispatchers.IO) { inspectNsp(context, uri) }
                report = result
                status = if (result.extensionLooksCorrect) {
                    "Análise inicial concluída. A estrutura identificada não garante que o pacote possa ser convertido em APK."
                } else {
                    "O arquivo selecionado não tem extensão .NSP; confira se escolheu o arquivo correto."
                }
                busy = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.Icon(Icons.Default.Android, contentDescription = null)
                    Spacer(Modifier.width(10.dp))
                    Text("MH Stories 2 Mod Tool", fontWeight = FontWeight.Bold)
                }
            })
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding)
                .verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Analisador de arquivos NSP", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Selecione um arquivo do Nintendo Switch. Esta versão faz verificações básicas e não envia o arquivo para a internet.")
                    Button(
                        onClick = { picker.launch(arrayOf("*/*")) },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        androidx.compose.material3.Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Selecionar arquivo NSP")
                    }
                    if (busy) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.width(22.dp).height(22.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text("Verificando…")
                        }
                    }
                }
            }

            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Icon(Icons.Default.Security, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Estado", fontWeight = FontWeight.Bold)
                    }
                    Text(status)
                }
            }

            report?.let { r ->
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Relatório de análise", fontWeight = FontWeight.Bold)
                        Text("Arquivo: ${r.fileName}")
                        Text("Tamanho: ${formatBytes(r.sizeBytes)}")
                        Text("Extensão .NSP: ${yesNo(r.extensionLooksCorrect)}")
                        Text("Contêiner ZIP legível: ${yesNo(r.zipReadable)}")
                        Text("Entradas ZIP encontradas: ${r.entryCount}")
                        Text("SHA-256: ${r.sha256 ?: "Não calculado"}")
                        if (r.selectedNames.isNotEmpty()) {
                            Divider()
                            Text("Nomes de entradas reconhecidas:", fontWeight = FontWeight.SemiBold)
                            r.selectedNames.forEach { Text("• $it") }
                        }
                        Divider()
                        r.notes.forEach { Text("• $it") }
                    }
                }
            }

            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Icon(Icons.Default.Info, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Limitações desta versão", fontWeight = FontWeight.Bold)
                    }
                    Text("Arquivos NSP de Nintendo Switch não são APKs e não são necessariamente arquivos ZIP comuns. Esta análise pode indicar que o formato não é legível pelo analisador padrão.")
                    Text("O aplicativo não descriptografa, não modifica o jogo e não converte NSP em APK. Um port Android exigiria adaptação ou reconstrução substancial do software.")
                }
            }
        }
    }
}

private fun inspectNsp(context: Context, uri: Uri): NspReport {
    val name = queryDisplayName(context, uri) ?: "arquivo.nsp"
    val extensionOk = name.endsWith(".nsp", ignoreCase = true)
    val temp = File(context.cacheDir, "nsp_check_${System.currentTimeMillis()}.bin")
    var size = 0L
    val maxBytes = 1024L * 1024L * 1024L // 1 GiB prototype safety limit
    var digest: String? = null

    try {
        val md = MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Não foi possível abrir o arquivo." }
            temp.outputStream().buffered().use { output ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    size += count
                    if (size > maxBytes) {
                        throw IllegalArgumentException("Arquivo maior que o limite de 1 GiB desta versão.")
                    }
                    md.update(buffer, 0, count)
                    output.write(buffer, 0, count)
                }
            }
        }
        digest = md.digest().joinToString("") { "%02x".format(it) }

        var count = 0
        val names = mutableListOf<String>()
        var zipReadable = false
        try {
            ZipFile(temp).use { zip ->
                zipReadable = true
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    count++
                    if (names.size < 20) names += entry.name
                }
            }
        } catch (_: Exception) {
            // An NSP is not guaranteed to be a conventional ZIP container.
        }

        val notes = mutableListOf<String>()
        if (!extensionOk) notes += "A extensão do arquivo não é .NSP."
        if (zipReadable) {
            notes += "O arquivo pode ser lido como ZIP, mas isso não comprova que seja um NSP válido."
        } else {
            notes += "O arquivo não pôde ser lido como ZIP comum. Isso pode ser normal para este formato."
        }
        notes += "O hash SHA-256 identifica este arquivo, mas não verifica se o jogo é autêntico."
        notes += "Nenhuma conversão ou modificação foi realizada."
        return NspReport(name, size, extensionOk, zipReadable, count, names, digest, notes)
    } catch (e: Exception) {
        return NspReport(name, size, extensionOk, false, 0, emptyList(), digest,
            listOf(e.message ?: "Erro desconhecido durante a análise.", "Nenhuma conversão ou modificação foi realizada."))
    } finally {
        temp.delete()
    }
}

private fun queryDisplayName(context: Context, uri: Uri): String? {
    return try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
    } catch (_: Exception) { null }
}

private fun yesNo(value: Boolean) = if (value) "Sim" else "Não"

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "%.1f KB".format(kb)
    val mb = kb / 1024.0
    if (mb < 1024) return "%.1f MB".format(mb)
    return "%.2f GB".format(mb / 1024.0)
}
